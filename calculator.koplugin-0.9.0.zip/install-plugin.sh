#!/bin/bash
 rsync -a --exclude='.git*' ../calculator.koplugin ../koreader/koreader-emulator-x86_64-pc-linux-gnu-debug/koreader/plugins/
