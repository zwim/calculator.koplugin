#!/bin/bash


adb push $1 /sdcard/koreader/plugins/
adb shell  "cd /sdcard/koreader/plugins/; unzip $1"
