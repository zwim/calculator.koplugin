local _ = require("gettext")
return {
    name = "calculator",
    fullname = _("Calculator"),
    description = _([[Calculates simple and complex math fourmulas.]]),
}
